File name format (example)

0-6.txt contains the correspondences between tillman00.jpg and tillman06.jpg where tillman06.jpg is being treated as the center (warping 0 onto 6)

File format

        X1 y1  (pixel location of feature in center image)             

        X�1 y�1 (pixel location of feature in image to be warped)

        .

        .

        .

        .

        Xn yn

        X�n y�n